# 🚀 Deploy KiranaBoost to GitHub Pages

Follow these steps **in order** to get your site live at  
`https://sreenathsjk.github.io/kiranaconnect/`

---

## Step 1 — Install Git & Node.js (skip if already installed)

Download and install:
- **Node.js 20+** → https://nodejs.org  
- **Git** → https://git-scm.com

Verify in terminal:
```bash
node --version    # should show v20.x.x
git --version     # should show git version 2.x.x
```

---

## Step 2 — Edit `vite.config.js`

Open `vite.config.js` and make sure the `base` matches your **exact repo name**:

```js
// If your GitHub repo URL is:
// https://github.com/sreenathsjk/kiranaconnect
// then set:

base: '/kiranaconnect/',
```

⚠️ This is the most common mistake. The base MUST match your repo name exactly.

---

## Step 3 — Initialize Git and Push to GitHub

```bash
# Inside the kiranaboost folder:

git init
git add .
git commit -m "Initial commit — KiranaBoost"

# Connect to your GitHub repo (replace URL with yours):
git remote add origin https://github.com/sreenathsjk/kiranaconnect.git

git branch -M main
git push -u origin main
```

---

## Step 4 — Enable GitHub Pages (do this once)

1. Go to your repo on GitHub
2. Click **Settings** tab
3. Click **Pages** in the left sidebar
4. Under **Source**, select **GitHub Actions**
5. Click **Save**

---

## Step 5 — GitHub Actions Auto-Deploys ✅

Once you push to `main`, GitHub Actions will automatically:
1. Install dependencies
2. Run `npm run build`
3. Deploy the `dist/` folder to GitHub Pages

Watch it run under the **Actions** tab in your repo.

**Your site will be live at:**  
👉 `https://sreenathsjk.github.io/kiranaconnect/`

---

## Manual Deploy (alternative to GitHub Actions)

If you prefer to deploy from your computer directly:

```bash
npm install
npm run deploy
```

This runs `vite build && gh-pages -d dist` and pushes to the `gh-pages` branch.

Then in GitHub Settings → Pages, set source to **Deploy from branch → gh-pages**.

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Site shows README instead of app | Check `vite.config.js` base matches repo name |
| Blank white page | Open browser console — likely a wrong `base` path |
| 404 on refresh | The `public/404.html` file handles this automatically |
| Build fails in Actions | Check Node version is 20 in the workflow file |
| Changes not showing | Hard refresh: `Ctrl+Shift+R` (Windows) / `Cmd+Shift+R` (Mac) |

---

## After Deployment — Updating the Site

Every time you push to `main`, GitHub Actions automatically rebuilds and redeploys:

```bash
# Make your changes, then:
git add .
git commit -m "Update: describe your change"
git push
```

That's it! 🎉
