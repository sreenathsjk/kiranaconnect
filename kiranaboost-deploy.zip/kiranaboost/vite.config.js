import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// ⚠️ IMPORTANT: Set this to your GitHub repository name
// Example: if your repo URL is https://github.com/sreenathsjk/kiranaconnect
// then set base: '/kiranaconnect/'
// If deploying to a custom domain (e.g. kiranaboost.in), set base: '/'

export default defineConfig({
  plugins: [react()],
  base: '/kiranaconnect/',   // 👈 Change this to your exact repo name
})
